# ESP32-Scale-Blynk

## About

This example Arduino based code implements procedure of reading weighing data from ESP32 based IoT scale and send it to Blynk app.
HX711 Weighing module is used in that project.Used Blynk Virtual Pin is V16.
It needs to be installed Blynk library in Arduino program.

Image of the scheme,scale and connections is shown at /IMG/scale.jpg
